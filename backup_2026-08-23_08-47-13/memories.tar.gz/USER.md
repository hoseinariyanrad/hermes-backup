User prefers responses in Persian (Farsi). Telegram user: @hosseingold1404. Enthusiast of Chinese anime (Donghua).
§
User's GitHub username is hoseinariyanrad. Backup repo is https://github.com/hoseinariyanrad/hermes-backup.