---
name: media-release-tracker
description: "Track daily media releases with per-item formatted messages."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [media, donghua, anime, tracking, monitoring, scheduled, reporting]
    related_skills: [product-price-monitor, competitor-news-monitor]
---

# Media Release Tracker

Monitor and report daily new releases of media content (Donghua/Chinese anime, Japanese anime, shows, movies) from tracking sites. Each item is sent as its own separate message with images, multilingual names, episode details, synopsis, and download links.

## When to Use

- "Check what new Donghua episodes came out today."
- "Track daily anime releases and notify me."
- "Report new media episodes with images and links."
- "Recommend anime based on my favorite genres."
- A cron tick fires for a scheduled daily media check.

## CRITICAL User Preference

**ONE item = ONE message. NEVER combine multiple items into a single message.**

If 5 anime released today, send exactly 5 separate messages. If 3, send 3. The number of messages MUST equal the number of items found. Send them back-to-back consecutively without waiting for user confirmation between messages.

This is non-negotiable. The user has corrected this behavior multiple times.

## Procedure — Setup (foreground, once)

### 1. Define the tracking scope

Record:
- Type of media (Donghua, anime, etc.)
- Specific titles to watch (if user has favorites)
- Source websites for tracking
- Language for output (e.g., Persian/Farsi)
- Download source preferences (Iranian sites, Telegram channels)

### 2. Define the output format

Standard per-item message format:
```
[Poster image inline]

**English Name**
**نام چینی:** (Chinese characters)
**نام فارسی:** (Persian name)

**ژانر:** (Genre)
**تعداد فصل‌ها:** (Total seasons)
- **فصل X:** Y قسمت (Z قسمت تا امروز)
**کل قسمت‌های منتشر شده:** X قسمت
**وضعیت:** در حال پخش / تمام شده
**روز پخش:** (Weekly air day)
**پلتفرم:** (Platform)
**امتیاز:** ⭐ X از ۱۰

**لینک آنلاین:** [link]

**خلاصه داستان:** (Full detailed synopsis in target language)

📥 **دانلود با زیرنویس فارسی:**
- [آپارات](link)
- [تلگرام](link)
```

### 3. Schedule the cron job

```
cronjob(action="create",
        schedule="30 5 * * *",  # adjust for timezone
        prompt="Load the media-release-tracker skill and run the daily check.",
        deliver="origin")
```

**Pitfall: Cron job model config** — Always pin model and provider explicitly:
```
/opt/venv/bin/hermes cron edit <job_id> --model hermes --provider openai-api
```
Without this, the cron job will fail with "no model configured" error.

## Procedure — Tick (each scheduled run)

### 4. Search for releases

Check tracking sources for today's new episodes:
- animexin.dev/release-date/ (comprehensive donghua schedule)
- mydonghuareview.com (release calendar)
- animeschedule.net (airing timetable)
- donghuasubs.com/schedule
- User's favorite title trackers

### 5. Count and send individually

Count exactly how many items were found. Then send EACH as its own separate Telegram message:
- Message 1: Anime #1 with all details
- Message 2: Anime #2 with all details
- Message 3: Anime #3 with all details
- ...and so on for ALL items

After the last item, send a summary: "Today X anime were updated."

### 6. Format each message

For each item, produce a complete message following the format defined in step 2. Include:
- Poster image (inline photo)
- Name in English, Chinese, and target language
- Episode/season counts (aired vs total)
- Full detailed synopsis (not brief — the user wants comprehensive descriptions)
- Download links for regional sites (e.g., Iranian sites for Persian users)

## Pitfalls

- **Combining items in one message** — This is the #1 user frustration. Each item MUST be its own message.
- **Sending only partial results** — If 9 anime released, send all 9, not just 1 or 2.
- **Missing the cron model config** — Cron jobs need explicit model/provider pinning or they fail silently. Always run: `/opt/venv/bin/hermes cron edit <job_id> --model hermes --provider openai-api`
- **Brief/insufficient synopsis** — User wants full, detailed story descriptions, not one-liners.
- **Missing episode counts** — Always include: seasons, episodes per season, episodes aired vs total.
- **Waiting for user confirmation between messages** — Send all messages consecutively without pausing.
- **Reporting hiatus episodes as new** — Always check if an anime is on hiatus. Recap/compilation episodes are NOT new releases.

### CRITICAL: Cron Job Delivery Limitation (Telegram)

**Problem:** When a cron job runs, its final response is delivered as a SINGLE text message on Telegram, regardless of how many items were found.

**Root cause:** The cron delivery mechanism sends the agent's final response as one `send_message` call. There is no built-in splitting.

**Solutions (pick one):**

1. **Script-based delivery (RECOMMENDED)** — Write a Python script that calls the Telegram API directly for each item.
   - Script reads bot token from `/data/.hermes/.env` (not environment variable)
   - Uses `sendPhoto` API for messages with images
   - Falls back to `sendMessage` if photo fails
   - Location: `/data/.hermes/scripts/donghua_telegram_send.py`

2. **`attach_to_session: true`** — Set on cron job so it runs in a controllable session. Use `send_message` tool for each item.

3. **Use `deliver: 'all'`** — Fans out to every connected channel, but still one message per channel.

### CRITICAL: Web Search Provider Failures

**Firecrawl keyless search** returns 403 Forbidden errors intermittently.

**Workaround:** Use `web_extract` on known schedule pages directly:
- `animexin.dev/release-date/` — Most comprehensive
- `mydonghuareview.com` — Monthly release calendar
- `animeschedule.net` — General anime timetable

### CRITICAL: Episode Count Accuracy

Always verify episode counts from the source. Count actual episodes listed, do not guess. If total is unknown, say "ongoing".

### CRITICAL: Hiatus Detection

**Always check if an anime is on hiatus before reporting it as new.**

**How to detect:**
- Search anime name + "hiatus" or "recap"
- Check donghuastream.org for official announcements
- Recap/compilation episodes are NOT new releases
- Example: BTTH S5 hiatus after ep 207 (July 12, 2026) until September 6, 2026

**When in doubt:** If description says "recap", "compilation", "summary", or "回顾", skip it.

### Genre-Based Recommendation Workflow

When user asks for recommendations:
1. Check memory for genre preferences (load USER.md)
2. Match recommendations to stated genres only
3. Provide comparison table scoring each on preferred genres
4. Include download links for preferred sources

Known preferences:
- Genres: Action, Comedy, Ecchi, Harem
- Language: Persian (Farsi)
- Sources: @godofanimeblack, aparat.com, nineanime.ir

## Verification

- [ ] Messages sent = items found.
- [ ] Each message has ONE item with its own image.
- [ ] Each includes: 3 language names, episodes, synopsis, download links.
- [ ] Cron job has model/provider pinned.
- [ ] No hiatus episodes reported as new.
