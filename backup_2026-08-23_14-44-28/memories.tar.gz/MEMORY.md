User's GitHub: hoseinariyanrad. Backup repo: https://github.com/hoseinariyanrad/hermes-backup with PAT token provided.
§
Cron jobs need --model hermes --provider openai-api explicitly set or they fail. Fix with: hermes cron edit JOB_ID --model hermes --provider openai-api. CLI path: /opt/venv/bin/hermes