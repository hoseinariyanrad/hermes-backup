User: Persian speaker, @hosseingold1404, Donghua enthusiast. GitHub: hoseinariyanrad/hermes-backup (PAT provided). Lives in Iran.
§
User's GitHub username is hoseinariyanrad. Backup repo is https://github.com/hoseinariyanrad/hermes-backup.
§
Donghua RULES: 1) Each anime = SEPARATE message, NEVER combine. 2) Msg count = anime count. 3) Include: poster, EN/CN/FA name, genre, seasons/episodes (released+total), full Persian synopsis, download links. 4) Send ALL back-to-back, no waiting. 5) Cron: 273e81fbf62e, 10AM Tehran, model=hermes, provider=openai-api. 6) Sources: animexin.dev, mydonghuareview.com, animeschedule.net, donghuasubs.com
§
User's favorite genres for anime/donghua/movies/series: Action, Comedy, Ecchi, Harem. Always recommend based on these genres when asked about anime, series, or movies.